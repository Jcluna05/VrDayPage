<?php if ( !defined( 'ABSPATH' ) ) {
	return;
}

require( 'framework.php' );
require( 'metafields.php' );
require( 'termmeta.php' );
require( 'shortcodes.php' );
