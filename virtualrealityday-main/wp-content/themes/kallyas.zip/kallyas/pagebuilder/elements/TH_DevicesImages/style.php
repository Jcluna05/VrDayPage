.el-di-type--img .el-di__laptop { background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/macbook.png); }
.el-di-type--vector .el-di__laptop { background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/macbook-air.svg); }
.el-di-type--img .el-di__smartphone { background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/iphone6.png); }
.el-di-type--vector .el-di__smartphone { background-image: url(<?php echo THEME_BASE_URI; ?>/images/devices/iphone6.svg); }